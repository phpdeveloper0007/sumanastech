<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use Illuminate\Support\Facades\Auth;
use App\Models\User;

class ProductController extends Controller
{
    public function index()
    {
        $products   =   Product::all();
        return view('product/list', compact('products'));
    }

    public function detail($id)
    {
        $product    =   Product::find($id);
        return view('product/detail', compact('product'));
    }

    public function purchase(Request $request)
    {
        try {
            $paymentMethod  =   $request->get('paymentMethod');
            $stripeCharge   =   ($request->get('charge') * 100);
            $stripeResp     =   (new User)->charge($stripeCharge, $paymentMethod);
            return response()->json($stripeResp);
        } catch (Exception $e) {
            dd($e);
        }        
    }
}
